﻿# -----------------------------------------------------------------------------
# Script: SimpleTypingError.ps1
# Author: ed wilson, msft
# Date: 09/07/2013 16:22:58
# Keywords: Using Set-PSDebug
# comments: Tracing the Script
# Windows PowerShell 4.0 Best Practices, Microsoft Press, 2013
# Chapter 19
# -----------------------------------------------------------------------------
$a = 2
$b = 5
$d = $a + $b
'The value of $c is: ' + $c
