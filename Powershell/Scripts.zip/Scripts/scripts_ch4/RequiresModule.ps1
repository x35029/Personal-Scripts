﻿#requires -modules activedirectory
#requires -version 4

Get-aduser -filter *