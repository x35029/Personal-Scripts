﻿# -----------------------------------------------------------------------------
# Script: Get-Bios.ps1
# Author: ed wilson, msft
# Date: 09/06/2013 16:25:22
# Keywords: Intro
# comments: Intro
# Windows PowerShell 4.0 Best Practices, Microsoft Press, 2013
# Chapter 12
# -----------------------------------------------------------------------------
Get-WmiObject -class Win32_Bios