﻿# -----------------------------------------------------------------------------
# Script: MultiLineDemo2.ps1
# Author: ed wilson, msft
# Date: 08/28/2013 13:41:36
# Keywords: help
# comments: Multi-Line comment
# Windows PowerShell 4.0 Best Practices, Microsoft Press, 2013
# Chapter 9
# -----------------------------------------------------------------------------
<# Get-Help 
   Get-Command #> 
"The above is a multiline comment"
