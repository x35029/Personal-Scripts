﻿# -----------------------------------------------------------------------------
# Script: Untitled1.ps1
# Author: ed wilson, msft
# Date: 09/08/2013 13:47:33
# Keywords: documentation
# comments: Get-Help
# Windows PowerShell 4.0 Best Practices, Microsoft Press, 2013
# Chapter 14
# -----------------------------------------------------------------------------