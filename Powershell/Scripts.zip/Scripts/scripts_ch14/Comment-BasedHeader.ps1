﻿ <#
   .Synopsis
    This is a comment-based block 
   .Description
    This illustrates comment-based help used as
    script header
   .Notes
    NAME:  Comment-BasedHeader.ps1
    AUTHOR: ed wilson, msft
    LASTEDIT: 09/08/2013 13:49:40
    KEYWORDS: Documentation, help
    Book: Windows PowerShell 4.0 Best Practices, Microsoft Press, 2013
    Chapter: 14 
   .Link
     Http://www.ScriptingGuys.com
 #Requires -Version 4.0
 #>