﻿# -----------------------------------------------------------------------------
# Script: StringArgs.ps1
# Author: ed wilson, msft
# Date: 09/06/2013 13:35:10
# Keywords: Input
# comments: Using 
# Windows PowerShell 4.0 Best Practices, Microsoft Press, 2013
# Chapter 11
# -----------------------------------------------------------------------------
'The value of arg0 ' + $args[0] + ' the value of arg1 ' + $args[1]