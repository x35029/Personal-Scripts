To customize this script, change the following (open Export_AD_Users_to_CSV.v1.0.ps1 with a script editor, like PS ISE). Amend the lines below:

1. line 21: amend location of your script, log and exported CSV report

2. line 41: Amend the OU, you wish to search

3. line 49: Amend the Active Directory DC you wish to connect to (This might be necessary in a Y2k3 AD domain with only one server running Active Directory web services

4. You might need to amend line 80 (This was specific to my project - User description was called "Directorate"). You might want to call it Description


If you require further assistance, you might contact me via the linek below:

www.itechguides.com/contact-me
